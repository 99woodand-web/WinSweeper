WinSweeper — Windows System Cleaner
===================================

WHAT IT DOES
------------
Finds junk on your PC (temp files, browser caches, Recycle Bin, recent-file
lists), shows you exactly how much space each category can free, and only
deletes what YOU select. Every clean is logged.

QUICK START
-----------
1. Double-click win_sweeper.exe (Windows will ask for administrator approval —
   this is needed to clean Windows Temp and the Recycle Bin).
2. The WinSweeper panel opens. Press SCAN — nothing is deleted by scanning.
3. Tick the categories you want, then press CLEAN SELECTED.

THE PANEL (small window)
------------------------
- Shows total reclaimable space and per-category sizes.
- Scan button / Clean selected button.
- X (top right) quits the app completely after confirmation.
- "Full dashboard" link opens the detailed browser view.

FULL DASHBOARD (http://127.0.0.1:7900)
--------------------------------------
- Detailed scan table with per-folder items.
- Cleaning history with an Export CSV button.
- Excluded paths: folders or file patterns (*.log) that are never touched.
- "Show panel window" button to bring the small window back.

SAFETY
------
- Scanning never deletes anything.
- Locked / in-use files are skipped, never forced.
- Browser caches are NOT cleaned while that browser is running (you'll see a
  note — close the browser and re-scan).
- Files younger than 24 hours in temp folders are left alone.
- All deletions are recorded in sweeper_log.txt.

DATA FILES (created next to the exe)
------------------------------------
- sweeper_log.txt      — deletion log (rotates at 5 MB)
- sweep_history.json   — cleaning history (shown on the dashboard)
- sweeper_config.json  — optional exclusions, e.g.
                        { "exclude_paths": ["C:\\some\\folder", "*.log"] }

CLOSING VS QUITTING
-------------------
- Closing the panel window (or Alt+F4) only hides it — WinSweeper keeps
  running. Launch the exe again to bring it back (it won't start a second copy).
- Use the X button inside the panel to actually quit the app.

TROUBLESHOOTING
---------------
- Nothing scanned / sizes look small: press Scan again; category sizes update
  after every clean.
- "Close Edge to clean this": the browser is running — close it and re-scan.
- The panel didn't open: open http://127.0.0.1:7900 in your browser.
